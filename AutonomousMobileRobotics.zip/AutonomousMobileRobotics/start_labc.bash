#!/bin/bash
roslaunch uol_turtlebot_simulator labc.launch
