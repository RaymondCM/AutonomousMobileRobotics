#!/bin/bash
roslaunch uol_turtlebot_simulator object-search-training.launch
