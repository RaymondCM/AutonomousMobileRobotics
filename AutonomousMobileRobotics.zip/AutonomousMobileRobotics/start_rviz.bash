#!/bin/bash
rosrun rviz rviz -d ./rviz/default.rviz
